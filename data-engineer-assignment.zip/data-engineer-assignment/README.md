# Data Engineer Assignment – Python + SQL + Pandas

This project solves the assignment for extracting customer purchase quantities 
for items X, Y, Z from a SQLite database.

Two solutions included:
1. SQL aggregation
2. Pandas aggregation

## Run
pip install -r requirements.txt
python sql_solution.py
python pandas_solution.py
