import sqlite3
import pandas as pd
import os

def fetch_data_pandas(db_path, output_path):
    conn = sqlite3.connect(db_path)

    customer = pd.read_sql("SELECT * FROM Customer", conn)
    sales = pd.read_sql("SELECT * FROM Sales", conn)
    items = pd.read_sql("SELECT * FROM Sales_Items", conn)

    df = sales.merge(customer, on="CustomerID").merge(items, on="SalesID")
    df = df[df["Age"].between(18, 35)]
    df["Quantity"] = df["Quantity"].fillna(0)

    grouped = df.groupby(["CustomerID", "Age", "Item"])["Quantity"].sum().reset_index()
    grouped = grouped[grouped["Quantity"] > 0]
    grouped.rename(columns={"CustomerID": "Customer"}, inplace=True)

    os.makedirs("output", exist_ok=True)
    grouped.to_csv(os.path.join(output_path, "output_pandas.csv"), sep=";", index=False)
    conn.close()

if __name__ == "__main__":
    fetch_data_pandas("xyz.db", "output")
