import sqlite3
import pandas as pd
import os

def fetch_data_sql(db_path, output_path):
    conn = sqlite3.connect(db_path)

    query = '''
        SELECT 
            c.CustomerID AS Customer,
            c.Age,
            si.Item,
            SUM(COALESCE(si.Quantity, 0)) AS Quantity
        FROM Customer c
        JOIN Sales s ON c.CustomerID = s.CustomerID
        JOIN Sales_Items si ON s.SalesID = si.SalesID
        WHERE c.Age BETWEEN 18 AND 35
        GROUP BY c.CustomerID, c.Age, si.Item
        HAVING SUM(COALESCE(si.Quantity, 0)) > 0
        ORDER BY c.CustomerID, si.Item;
    '''

    df = pd.read_sql(query, conn)
    os.makedirs("output", exist_ok=True)
    df.to_csv(os.path.join(output_path, "output_sql.csv"), sep=";", index=False)
    conn.close()

if __name__ == "__main__":
    fetch_data_sql("xyz.db", "output")
